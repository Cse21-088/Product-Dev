import dotenv from 'dotenv';
dotenv.config();

console.log("Firebase API Key:", process.env.API_KEY);