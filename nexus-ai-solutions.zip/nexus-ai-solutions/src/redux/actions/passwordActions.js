// actions/passwordActions.js
import { SHOW_PASSWORD } from "./types";

export const showPassword = () => ({
  type: SHOW_PASSWORD,
});