// actions/types.js
export const SHOW_PASSWORD = "SHOW_PASSWORD";