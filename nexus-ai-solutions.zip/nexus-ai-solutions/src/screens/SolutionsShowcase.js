import { useState, useEffect } from "react";
import {
  Star,
  Calendar,
  ArrowRight,
  ChevronLeft,
  ChevronRight,
  Upload,
  X,
} from "lucide-react";
import ContactUs from "./ContactUs";
import { motion } from "framer-motion";
import { collection, getDocs, addDoc } from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL, getStorage } from 'firebase/storage';
import { firestore } from '../database/firebase';

const SolutionsShowcase = () => {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [showContactForm, setShowContactForm] = useState(false);
  const [selectedSolution, setSelectedSolution] = useState(null);
  const [solutions, setSolutions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [showUploadForm, setShowUploadForm] = useState(false);
  const [uploadData, setUploadData] = useState({
    title: '',
    description: '',
    industry: '',
    features: '',
    image: null
  });
  const [uploadProgress, setUploadProgress] = useState(0);

  const testimonials = [
    {
      name: "Mr ADMINI",
      company: "TechCorp Global",
      comment:
        "NEXUS solutions transformed our data processing capabilities.",
      rating: 5,
      image: "https://scontent.fgbe3-1.fna.fbcdn.net/v/t39.30808-6/434462439_10161236670807641_7470107635981503663_n.jpg?stp=cp6_dst-jpg_tt6&_nc_cat=106&ccb=1-7&_nc_sid=6ee11a&_nc_ohc=JJVs6en40rUQ7kNvgGBnQJ9&_nc_zt=23&_nc_ht=scontent.fgbe3-1.fna&_nc_gid=A_TAwOUET2G3LyNf1_ajxsL&oh=00_AYFmJvLon20Of-C0Q6SiAOIPzF2Yu_V02GXr_cqsZppjrg&oe=67D00ECA",
    },
    {
      name: "Katlego Lulwami",
      company: "Healthcare Plus",
      comment: "Outstanding results in patient data analysis.",
      rating: 5,
      image: "https://scontent.fgbe3-1.fna.fbcdn.net/v/t39.30808-1/472321948_8919582651493922_3888731328863953025_n.jpg?stp=dst-jpg_s480x480_tt6&_nc_cat=102&ccb=1-7&_nc_sid=e99d92&_nc_ohc=Gp15LsbRNAIQ7kNvgGCcapw&_nc_zt=24&_nc_ht=scontent.fgbe3-1.fna&_nc_gid=Adt26b3a6Pil1g40oOq7WQs&oh=00_AYHXT8nne_OA1EWuitAD7wDrSZdlaOA9lcDLFO80WmtZbQ&oe=67CFF729",
    },
  ];

  const articles = [
    {
      title: "The Future of Digital Solutions",
      excerpt: "Exploring how technology is revolutionizing business...",
      date: "2025-01-15",
      image: "https://images.pexels.com/photos/8439061/pexels-photo-8439061.jpeg?auto=compress&cs=tinysrgb&w=1200",
    },
    {
      title: "Cloud Computing Breakthroughs",
      excerpt: "New developments in cloud infrastructure...",
      date: "2025-01-10",
      image: "https://media.istockphoto.com/id/1453664340/photo/a-futuristic-glowing-quantum-computer-unit-3d-render.jpg?b=1&s=612x612&w=0&k=20&c=kk44vbu8yWdpQUoKX5uf0JRXnJXT87lgHo8S5gegcI4=",
    },
  ];

  const events = [
    {
      title: "Tech Summit 2025",
      date: "March 15, 2025",
      location: "San Francisco, CA",
      description: "Annual gathering of industry leaders",
      image: "https://images.pexels.com/photos/7862616/pexels-photo-7862616.jpeg?auto=compress&cs=tinysrgb&w=1200"
    },
    {
      title: "Innovation Forum",
      date: "April 5, 2025",
      location: "London, UK",
      description: "Showcase of latest technologies",
    },
  ];

  const handleSolutionClick = (solution) => {
    setSelectedSolution(solution);
    setShowContactForm(true);
  };

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setUploadData(prev => ({
        ...prev,
        image: file
      }));
    }
  };

  const handleUpload = async (e) => {
    e.preventDefault();
    if (!uploadData.image || !uploadData.title || !uploadData.description) return;

    try {
      setUploadProgress(0);
      const storage = getStorage();
      // Upload image to Firebase Storage
      const imageRef = ref(storage, `solutions/${uploadData.image.name}`);
      const uploadTask = uploadBytes(imageRef, uploadData.image);
      
      uploadTask.on('state_changed', 
        (snapshot) => {
          const progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
          setUploadProgress(progress);
        },
        (error) => {
          console.error('Error uploading image:', error);
          setError('Failed to upload image. Please try again.');
        },
        async () => {
          // Get download URL
          const downloadURL = await getDownloadURL(imageRef);
          
          // Add solution to Firestore
          const solutionData = {
            title: uploadData.title,
            description: uploadData.description,
            industry: uploadData.industry,
            features: uploadData.features.split(',').map(f => f.trim()),
            imageData: downloadURL,
            createdAt: new Date()
          };

          await addDoc(collection(firestore, 'gallery'), solutionData);
          
          // Reset form and refresh solutions
          setUploadData({
            title: '',
            description: '',
            industry: '',
            features: '',
            image: null
          });
          setShowUploadForm(false);
          fetchGalleryItems();
        }
      );
    } catch (error) {
      console.error('Error adding solution:', error);
      setError('Failed to add solution. Please try again.');
    }
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2
      }
    }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        duration: 0.5
      }
    }
  };

  const fetchGalleryItems = async () => {
    setLoading(true);
    try {
      const querySnapshot = await getDocs(collection(firestore, 'gallery'));
      const items = querySnapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      }));
      setSolutions(items);
      setError(null);
    } catch (error) {
      console.error('Error fetching gallery items:', error);
      setError('Failed to load solutions. Please try again later.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchGalleryItems();
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-indigo-950 to-purple-950 text-white">
      {/* Background Effects */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        <div className="absolute top-1/4 right-1/4 w-96 h-96 bg-indigo-500/20 rounded-full filter blur-3xl animate-pulse"></div>
        <div className="absolute bottom-1/4 left-1/4 w-96 h-96 bg-purple-500/10 rounded-full filter blur-3xl animate-pulse delay-1000"></div>
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Software Solutions Section */}
        <motion.section
          className="mb-20"
          initial="hidden"
          animate="visible"
          variants={containerVariants}
        >
          <div className="flex justify-between items-center mb-8">
            <motion.h2
              className="text-3xl font-bold bg-gradient-to-r from-indigo-400 to-purple-400 text-transparent bg-clip-text"
              variants={itemVariants}
            >
              Our Solutions
            </motion.h2>
            {/* <button
              onClick={() => setShowUploadForm(true)}
              className="bg-indigo-500 hover:bg-indigo-600 text-white px-4 py-2 rounded-lg flex items-center gap-2 transition-colors"
            >
              <Upload size={20} />
              Add Solution
            </button> */}
          </div>

          {loading ? (
            <div className="flex justify-center items-center h-64">
              <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-indigo-500"></div>
            </div>
          ) : error ? (
            <div className="text-center text-indigo-500 p-4 bg-indigo-500/10 rounded-lg">
              {error}
            </div>
          ) : solutions.length === 0 ? (
            <div className="text-center text-gray-400 p-4">
              No solutions available at the moment.
            </div>
          ) : (
            <motion.div
              className="grid grid-cols-1 md:grid-cols-3 gap-8"
              variants={containerVariants}
            >
              {solutions.map((solution, index) => (
                <motion.div
                  key={solution.id}
                  variants={itemVariants}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className="bg-gray-900/50 backdrop-blur-sm rounded-xl border border-indigo-500/20 p-6 hover:border-indigo-500 transition-all cursor-pointer"
                  onClick={() => handleSolutionClick(solution)}
                >
                  <div className="overflow-hidden rounded-lg mb-4">
                    <motion.img
                      src={solution.imageData}
                      alt={solution.title}
                      className="w-full h-48 object-cover hover:scale-110 transition-transform duration-500"
                      onError={(e) => {
                        e.target.src = 'https://via.placeholder.com/400x300?text=Image+Not+Found';
                      }}
                    />
                  </div>
                  <h3 className="text-xl font-semibold mb-2">{solution.title}</h3>
                  <p className="text-gray-400 mb-4 line-clamp-3">
                    {solution.description}
                  </p>
                  <div className="space-y-2">
                    {Array.isArray(solution.features) && solution.features.map((feature, idx) => (
                      <span
                        key={idx}
                        className="inline-block bg-indigo-500/10 text-indigo-400 text-sm px-3 py-1 rounded-full mr-2 mb-2"
                      >
                        {feature}
                      </span>
                    ))}
                  </div>
                  <div className="mt-4 flex justify-between items-center">
                    <span className="text-indigo-400 text-sm">
                      {solution.industry}
                    </span>
                    <motion.button
                      whileHover={{ x: 5 }}
                      className="text-indigo-400 flex items-center gap-2"
                    >
                      Learn More <ArrowRight className="w-4 h-4" />
                    </motion.button>
                  </div>
                </motion.div>
              ))}
            </motion.div>
          )}
        </motion.section>

        {/* Testimonials Section */}
        <section className="mb-20">
          <h2 className="text-3xl font-bold bg-gradient-to-r from-indigo-400 to-purple-400 text-transparent bg-clip-text mb-8">
            Client Feedback
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {testimonials.map((testimonial, index) => (
              <div
                key={index}
                className="bg-gray-900/50 backdrop-blur-sm rounded-xl border border-indigo-500/20 p-6"
              >
                <div className="flex items-start gap-4">
                  <img
                    src={testimonial.image}
                    alt={testimonial.name}
                    className="w-16 h-16 rounded-full"
                  />
                  <div>
                    <div className="flex gap-1 mb-2">
                      {[...Array(testimonial.rating)].map((_, i) => (
                        <Star
                          key={i}
                          className="w-4 h-4 fill-indigo-500 text-indigo-500"
                        />
                      ))}
                    </div>
                    <p className="text-gray-300 mb-2">
                      "{testimonial.comment}"
                    </p>
                    <p className="font-medium">{testimonial.name}</p>
                    <p className="text-sm text-gray-400">
                      {testimonial.company}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Articles Section */}
        <section className="mb-20">
          <h2 className="text-3xl font-bold bg-gradient-to-r from-indigo-400 to-purple-400 text-transparent bg-clip-text mb-8">
            Latest Articles
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {articles.map((article, index) => (
              <div
                key={index}
                className="bg-gray-900/50 backdrop-blur-sm rounded-xl border border-indigo-500/20 overflow-hidden group"
              >
                <img
                  src={article.image}
                  alt={article.title}
                  className="w-full h-48 object-cover"
                />
                <div className="p-6">
                  <h3 className="text-xl font-semibold mb-2">
                    {article.title}
                  </h3>
                  <p className="text-gray-400 mb-4">{article.excerpt}</p>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-400">
                      {article.date}
                    </span>
                    <button className="text-indigo-400 group-hover:text-indigo-300 flex items-center gap-2">
                      Read more <ArrowRight className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Events Section */}
        <section className="mb-20">
          <h2 className="text-3xl font-bold bg-gradient-to-r from-indigo-400 to-purple-400 text-transparent bg-clip-text mb-8">
            Upcoming Events
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {events.map((event, index) => (
              <div
                key={index}
                className="bg-gray-900/50 backdrop-blur-sm rounded-xl border border-indigo-500/20 p-6"
              >
                <div className="flex items-start gap-4">
                  <div className="bg-indigo-500/10 p-3 rounded-lg">
                    <Calendar className="w-6 h-6 text-indigo-400" />
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold mb-2">
                      {event.title}
                    </h3>
                    <p className="text-indigo-400 mb-1">{event.date}</p>
                    <p className="text-gray-400 mb-2">{event.location}</p>
                    <p className="text-gray-300">{event.description}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Photo Gallery */}
        <section>
          <h2 className="text-3xl font-bold bg-gradient-to-r from-indigo-400 to-purple-400 text-transparent bg-clip-text mb-8">
            Event Gallery
          </h2>
          <div className="relative">
            <div className="overflow-hidden rounded-xl aspect-video">
              <img
                src="https://images.pexels.com/photos/7862616/pexels-photo-7862616.jpeg?auto=compress&cs=tinysrgb&w=1200"
                alt="Event"
                className="w-full h-full object-cover"
              />
            </div>
            <div className="absolute top-1/2 -translate-y-1/2 flex justify-between w-full px-4">
              <button
                onClick={() => setCurrentSlide((prev) => (prev - 1 + 3) % 3)}
                className="bg-gray-900/50 hover:bg-gray-900/70 text-white p-2 rounded-full backdrop-blur-sm"
              >
                <ChevronLeft className="w-6 h-6" />
              </button>
              <button
                onClick={() => setCurrentSlide((prev) => (prev + 1) % 3)}
                className="bg-gray-900/50 hover:bg-gray-900/70 text-white p-2 rounded-full backdrop-blur-sm"
              >
                <ChevronRight className="w-6 h-6" />
              </button>
            </div>
          </div>
        </section>

        {/* Upload Solution Modal */}
        {showUploadForm && (
          <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center">
            <div className="bg-gray-900 rounded-xl border border-indigo-500/20 p-6 w-full max-w-2xl">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-semibold">Add New Solution</h2>
                <button
                  onClick={() => setShowUploadForm(false)}
                  className="p-2 hover:bg-gray-800 rounded-lg transition-colors"
                >
                  <X size={20} className="text-gray-400" />
                </button>
              </div>
              <form onSubmit={handleUpload} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-1">
                    Title
                  </label>
                  <input
                    type="text"
                    value={uploadData.title}
                    onChange={(e) => setUploadData(prev => ({ ...prev, title: e.target.value }))}
                    className="w-full bg-gray-800 border border-indigo-500/20 rounded-lg px-4 py-2 text-white placeholder-gray-500 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 transition-colors"
                    placeholder="Enter solution title"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-1">
                    Description
                  </label>
                  <textarea
                    value={uploadData.description}
                    onChange={(e) => setUploadData(prev => ({ ...prev, description: e.target.value }))}
                    className="w-full bg-gray-800 border border-indigo-500/20 rounded-lg px-4 py-2 text-white placeholder-gray-500 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 transition-colors resize-none h-32"
                    placeholder="Enter solution description"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-1">
                    Industry
                  </label>
                  <input
                    type="text"
                    value={uploadData.industry}
                    onChange={(e) => setUploadData(prev => ({ ...prev, industry: e.target.value }))}
                    className="w-full bg-gray-800 border border-indigo-500/20 rounded-lg px-4 py-2 text-white placeholder-gray-500 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 transition-colors"
                    placeholder="Enter industry"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-1">
                    Features (comma-separated)
                  </label>
                  <input
                    type="text"
                    value={uploadData.features}
                    onChange={(e) => setUploadData(prev => ({ ...prev, features: e.target.value }))}
                    className="w-full bg-gray-800 border border-indigo-500/20 rounded-lg px-4 py-2 text-white placeholder-gray-500 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 transition-colors"
                    placeholder="Enter features separated by commas"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-1">
                    Solution Image
                  </label>
                  <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-indigo-500/20 border-dashed rounded-lg">
                    <div className="space-y-1 text-center">
                      <Upload className="mx-auto h-12 w-12 text-gray-400" />
                      <div className="flex text-sm text-gray-400">
                        <label
                          htmlFor="file-upload"
                          className="relative cursor-pointer bg-gray-900 rounded-md font-medium text-indigo-400 hover:text-indigo-300 focus-within:outline-none focus-within:ring-2 focus-within:ring-offset-2 focus-within:ring-indigo-500"
                        >
                          <span>Upload a file</span>
                          <input
                            id="file-upload"
                            name="file-upload"
                            type="file"
                            className="sr-only"
                            accept="image/*"
                            onChange={handleImageChange}
                            required
                          />
                        </label>
                        <p className="pl-1">or drag and drop</p>
                      </div>
                      <p className="text-xs text-gray-500">
                        PNG, JPG, GIF up to 10MB
                      </p>
                    </div>
                  </div>
                </div>
                {uploadProgress > 0 && (
                  <div className="w-full bg-gray-800 rounded-full h-2.5">
                    <div
                      className="bg-indigo-500 h-2.5 rounded-full transition-all duration-300"
                      style={{ width: `${uploadProgress}%` }}
                    ></div>
                  </div>
                )}
                <button
                  type="submit"
                  className="w-full bg-indigo-500 hover:bg-indigo-600 text-white rounded-lg px-4 py-2 transition-colors"
                >
                  Upload Solution
                </button>
              </form>
            </div>
          </div>
        )}

        {/* Contact Form Modal */}
        {showContactForm && (
          <ContactUs
            onClose={() => setShowContactForm(false)}
            initialData={selectedSolution ? {
              jobDetails: `I'm interested in your ${selectedSolution.title} solution for the ${selectedSolution.industry} industry.\n\nSpecific requirements: ${selectedSolution.description}`
            } : null}
          />
        )}
      </div>
    </div>
  );
};

export default SolutionsShowcase;
