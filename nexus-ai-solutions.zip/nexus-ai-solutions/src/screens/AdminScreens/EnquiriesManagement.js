import { useState, useEffect } from 'react';
import { firestore } from '../../database/firebase';
import { collection, query, orderBy, onSnapshot, doc, updateDoc } from 'firebase/firestore';
import { Mail, CheckCircle, XCircle, Clock } from 'lucide-react';

const EnquiriesManagement = () => {
  const [enquiries, setEnquiries] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedEnquiry, setSelectedEnquiry] = useState(null);
  const [response, setResponse] = useState('');

  useEffect(() => {
    const q = query(collection(firestore, 'contactSubmissions'), orderBy('timestamp', 'desc'));
    
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const enquiriesList = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data(),
        timestamp: doc.data().timestamp?.toDate()
      }));
      setEnquiries(enquiriesList);
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const handleRespond = async (enquiryId) => {
    if (!response.trim()) return;

    try {
      await updateDoc(doc(firestore, 'contactSubmissions', enquiryId), {
        response,
        respondedAt: new Date(),
        status: 'responded'
      });

      setResponse('');
      setSelectedEnquiry(null);
    } catch (error) {
      console.error('Error responding to enquiry:', error);
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'responded':
        return <CheckCircle className="text-green-500" size={20} />;
      case 'pending':
        return <Clock className="text-yellow-500" size={20} />;
      default:
        return <Mail className="text-blue-500" size={20} />;
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-indigo-500"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Enquiries List */}
        <div className="bg-gray-900/50 backdrop-blur-sm rounded-xl border border-indigo-500/20 p-6">
          <h2 className="text-xl font-semibold mb-4">Customer Enquiries</h2>
          <div className="space-y-4">
            {enquiries.map((enquiry) => (
              <div
                key={enquiry.id}
                className={`p-4 rounded-lg border ${
                  selectedEnquiry?.id === enquiry.id
                    ? 'border-indigo-500 bg-indigo-500/10'
                    : 'border-indigo-500/20 hover:border-indigo-500/40'
                } cursor-pointer transition-all`}
                onClick={() => setSelectedEnquiry(enquiry)}
              >
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    {getStatusIcon(enquiry.status)}
                    <span className="font-medium">{enquiry.name}</span>
                  </div>
                  <span className="text-sm text-gray-400">
                    {enquiry.timestamp?.toLocaleDateString()}
                  </span>
                </div>
                <p className="text-gray-400 text-sm line-clamp-2">{enquiry.jobDetails}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Response Panel */}
        <div className="bg-gray-900/50 backdrop-blur-sm rounded-xl border border-indigo-500/20 p-6">
          {selectedEnquiry ? (
            <div className="space-y-4">
              <h2 className="text-xl font-semibold">Respond to Enquiry</h2>
              <div className="space-y-4">
                <div>
                  <h3 className="text-sm font-medium text-gray-400">From</h3>
                  <p>{selectedEnquiry.name}</p>
                  <p className="text-sm text-gray-400">{selectedEnquiry.email}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-gray-400">Company</h3>
                  <p>{selectedEnquiry.company}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-gray-400">Enquiry Details</h3>
                  <p className="text-gray-300">{selectedEnquiry.jobDetails}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-gray-400 mb-2">Your Response</h3>
                  <textarea
                    value={response}
                    onChange={(e) => setResponse(e.target.value)}
                    className="w-full h-32 bg-gray-800 border border-indigo-500/20 rounded-lg px-4 py-2 text-white placeholder-gray-500 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 transition-colors resize-none"
                    placeholder="Type your response..."
                  />
                </div>
                <button
                  onClick={() => handleRespond(selectedEnquiry.id)}
                  className="w-full bg-indigo-500 hover:bg-indigo-600 text-white rounded-lg px-4 py-2 transition-colors"
                >
                  Send Response
                </button>
              </div>
            </div>
          ) : (
            <div className="flex items-center justify-center h-full text-gray-400">
              Select an enquiry to respond
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default EnquiriesManagement; 