import ClientDatabiz from "../../assets/images/client-databiz.svg";
import ClientAudiophile from "../../assets/images/client-audiophile.svg";
import ClientMeet from "../../assets/images/client-meet.svg";
import ClientMaker from "../../assets/images/client-maker.svg";

export default function Hero() {
  return (
    <div className="px-5 mt-8 mb-48 lg:pt-20 lg:pr-32">
     
    </div>
  );
}
