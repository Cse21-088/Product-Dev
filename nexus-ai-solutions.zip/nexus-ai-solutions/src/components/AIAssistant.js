import { useState, useRef, useEffect } from 'react';
import { Send, Bot, User } from 'lucide-react';
import { firestore } from '../database/firebase';
import { collection, addDoc, query, orderBy, onSnapshot } from 'firebase/firestore';

const AIAssistant = () => {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = async (e) => {
    e.preventDefault();
    if (!input.trim()) return;

    const userMessage = {
      text: input,
      sender: 'user',
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    try {

      const aiResponse = {
        text: "I'm your AI assistant. I can help you with information about our solutions and services. How can I assist you today?",
        sender: 'ai',
        timestamp: new Date()
      };

      // Store the conversation in Firestore
      await addDoc(collection(firestore, 'chatHistory'), {
        userMessage: userMessage.text,
        aiResponse: aiResponse.text,
        timestamp: new Date()
      });

      setMessages(prev => [...prev, aiResponse]);
    } catch (error) {
      console.error('Error in AI response:', error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed bottom-4 right-4 w-96 h-[600px] bg-gray-900/95 backdrop-blur-sm rounded-xl border border-indigo-500/20 shadow-xl flex flex-col">
      {/* Header */}
      <div className="p-4 border-b border-indigo-500/20 flex items-center gap-2">
        <Bot className="text-indigo-400" size={24} />
        <h3 className="text-lg font-semibold">AI Assistant</h3>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((message, index) => (
          <div
            key={index}
            className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div
              className={`max-w-[80%] rounded-lg p-3 ${
                message.sender === 'user'
                  ? 'bg-indigo-500 text-white'
                  : 'bg-gray-800 text-gray-200'
              }`}
            >
              <div className="flex items-center gap-2 mb-1">
                {message.sender === 'ai' ? (
                  <Bot size={16} className="text-indigo-400" />
                ) : (
                  <User size={16} className="text-white" />
                )}
                <span className="text-xs opacity-70">
                  {message.sender === 'user' ? 'You' : 'AI Assistant'}
                </span>
              </div>
              <p>{message.text}</p>
            </div>
          </div>
        ))}
        {isLoading && (
          <div className="flex justify-start">
            <div className="bg-gray-800 rounded-lg p-3">
              <div className="flex gap-2">
                <div className="w-2 h-2 bg-indigo-400 rounded-full animate-bounce" />
                <div className="w-2 h-2 bg-indigo-400 rounded-full animate-bounce delay-100" />
                <div className="w-2 h-2 bg-indigo-400 rounded-full animate-bounce delay-200" />
              </div>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input */}
      <form onSubmit={handleSend} className="p-4 border-t border-indigo-500/20">
        <div className="flex gap-2">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Type your message..."
            className="flex-1 bg-gray-800 border border-indigo-500/20 rounded-lg px-4 py-2 text-white placeholder-gray-500 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 transition-colors"
          />
          <button
            type="submit"
            disabled={isLoading}
            className="bg-indigo-500 hover:bg-indigo-600 text-white rounded-lg px-4 py-2 transition-colors disabled:opacity-50"
          >
            <Send size={20} />
          </button>
        </div>
      </form>
    </div>
  );
};

export default AIAssistant; 